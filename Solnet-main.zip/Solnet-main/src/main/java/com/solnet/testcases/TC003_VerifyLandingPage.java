package com.solnet.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.solnet.pages.LoginPage;
import com.solnet.testng.api.base.ProjectSpecificMethods;

public class TC003_VerifyLandingPage extends ProjectSpecificMethods{	

	@BeforeTest
	public void setValues() {
		testCaseName = "TC003_Verify Landing Page";
		testDescription = "Verify Landing Page testCase using valid UserName, Passowrd and LogOut";
		nodes = "VerifyLandingPage";
		authors = "Anwar";
		category = "Smoke";
		dataSheetName = "TC003";
	}

	@Test(dataProvider = "fetchData")
	public void VerifyLandingPage(String uName, String pwd, String name) {
		new LoginPage(driver, node)
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.verifyLoggedName(name)
		.clickLogout();		
	}


}





