package com.solnet.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.solnet.pages.LoginPage;
import com.solnet.testng.api.base.ProjectSpecificMethods;

public class TC001_LoginLogOut extends ProjectSpecificMethods{	

	@BeforeTest
	public void setValues() {
		testCaseName = "TC001_Login and LogOut";
		testDescription = "Login testCase using valid UserName, Password and LogOut";
		nodes = "Login";
		authors = "Anwar";
		category = "Smoke";
		dataSheetName = "TC001"; 
	}

	@Test(dataProvider = "fetchData")
	public void Login(String uName, String pwd) {
		new LoginPage(driver, node)
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickLogout();		
	}


}





