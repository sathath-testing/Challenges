package com.solnet.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.solnet.pages.LoginPage;
import com.solnet.testng.api.base.ProjectSpecificMethods;

public class TC006_VerifyfavoritesPage extends ProjectSpecificMethods{	

	@BeforeTest
	public void setValues() {
		testCaseName = "TC006_VerifyfavoritesPage";
		testDescription = "Verify Favorites Page testCase using valid UserName, Password and LogOut";
		nodes = "VerifyfavoritesPage";
		authors = "Anwar";
		category = "Smoke";
		dataSheetName = "TC006"; 
	}

	@Test(dataProvider = "fetchData")
	public void VerifyfavoritesPage(String uName, String pwd,String name) {
		new LoginPage(driver, node)
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickImportantTasks()
		.verifyFavoritespage(name)
		.clickLogout();		
	}


}





