package com.solnet.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.solnet.pages.LoginPage;
import com.solnet.testng.api.base.ProjectSpecificMethods;

import utils.DataLibrary;

public class TC004_AddandRemoveTasks extends ProjectSpecificMethods{	

	@BeforeTest
	public void setValues() {
		testCaseName = "TC004_AddandRemoveTasks";
		testDescription = "Add and remove Tasks testCase using valid UserName, Password and LogOut";
		nodes = "AddandRemoveTasks";
		authors = "Anwar";
		category = "Smoke";
		dataSheetName = "TC004"; 
	}

	@Test(dataProvider = "fetchData")
	public void AddTasks(String uName, String pwd,String name,String tsktitle, String tskdesc,String data) throws InterruptedException {
		new LoginPage(driver, node)
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.verifyLoggedName(name)
		.enterTaskTitle(tsktitle)
		.enterTaskDescription(tskdesc)
		.ClickDate()
		.enterTaskDate(DataLibrary.getcurrentdate())
		.clickAddTask()
		.clickAllTasks()
		.verifyAllTaskspage(data)
		.clickMyDay()
		.LandingPage()
		.removetaks()
		.clickLogout();
		
	}

}






