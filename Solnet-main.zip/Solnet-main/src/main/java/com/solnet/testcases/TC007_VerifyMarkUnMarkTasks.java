package com.solnet.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.solnet.pages.LoginPage;
import com.solnet.testng.api.base.ProjectSpecificMethods;

public class TC007_VerifyMarkUnMarkTasks extends ProjectSpecificMethods{	

	@BeforeTest
	public void setValues() {
		testCaseName = "TC007_VerifyMarkUnMarkTasks";
		testDescription = "Verify Marking UnMarking Tasks  testCase using valid UserName, Password and LogOut";
		nodes = "VerifyMarkUnMarkTasks";
		authors = "Anwar";
		category = "Smoke";
		dataSheetName = "TC007"; 
	}

	@Test(dataProvider = "fetchData")
	public void VerifyMarkUnMarkTasks(String uName, String pwd,String name) throws InterruptedException {
		new LoginPage(driver, node)
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickAllTasks()
		.verifyAllTaskspage(name)
		.verifySelected()
		.verifyunSelected()
		.clickLogout();
	}


}





