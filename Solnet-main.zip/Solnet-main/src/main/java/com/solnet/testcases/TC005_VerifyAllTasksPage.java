package com.solnet.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.solnet.pages.LoginPage;
import com.solnet.testng.api.base.ProjectSpecificMethods;

public class TC005_VerifyAllTasksPage extends ProjectSpecificMethods{	

	@BeforeTest
	public void setValues() {
		testCaseName = "TC005_VerifyAllTasksPage";
		testDescription = "Verify AllTasks Page testCase using valid UserName, Password and LogOut";
		nodes = "VerifyAllTasksPage";
		authors = "Anwar";
		category = "Smoke";
		dataSheetName = "TC005"; 
	}

	@Test(dataProvider = "fetchData")
	public void VerifyAllTasksPage(String uName, String pwd,String name) {
		new LoginPage(driver, node)
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickAllTasks()
		.verifyAllTaskspage(name)
		.clickLogout();		
	}


}





