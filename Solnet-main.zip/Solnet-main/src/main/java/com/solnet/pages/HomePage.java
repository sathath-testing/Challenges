package com.solnet.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import com.aventstack.extentreports.ExtentTest;
import com.solnet.testng.api.base.ProjectSpecificMethods;



public class HomePage extends ProjectSpecificMethods{

	public HomePage(RemoteWebDriver driver, ExtentTest node){
		this.driver = driver;
		this.node = node;

	}

	public HomePage LandingPage() {
		click(locateElement("xpath","//div[text()='My day']"));
		return new HomePage(driver, node);		
	}

	public HomePage clickMyDay() {
		click(locateElement("xpath","//div[text()=\" My day \"]"));
		return new HomePage(driver, node);
	}


	public HomePage verifyLoggedName(String data) {
		verifyPartialText(locateElement("xpath","//div[text()='My day']"), data);
		return this;
	}


	public HomePage verifySelected() throws InterruptedException {
		click(locateElement("xpath","(//mat-card[contains(@class,'home')])[1]//mat-checkbox"));
		Thread.sleep(2000);
		return this;			
	}
	
	

	public HomePage verifyunSelected() {
		click(locateElement("xpath","(//mat-card[contains(@class,'home')])[1]//mat-checkbox"));
		return this;			
	}

	public HomePage removetaks() {
		click(locateElement("xpath","//span[contains(@class,'ng')]/parent::mat-card-content[contains(@class,'mat')]/mat-icon[text()=\"close\"]"));
		return this;			
	}


	public HomePage clickAllTasks(){
		click(locateElement("xpath","//div[text()=' All Tasks ']"));
		return new HomePage(driver, node);
	}

	public HomePage clickImportantTasks(){
		click(locateElement("xpath","//div[text()=' Important Tasks ']"));
		return new HomePage(driver, node);
	}



	public LoginPage clickLogout() {
		click(locateElement("xpath","//*[contains(text(),\"logout\")]"));
		return new LoginPage(driver, node);

	}


	public HomePage verifyHomepage() {
		verifyDisplayed(locateElement("xpath","//div[text()='My day']"));
		return this;
	}
	public HomePage ClickDate() throws InterruptedException{
		WebElement header1=driver.findElement(By.xpath("//button[@type=\"button\"]"));
		header1.click();
		return this;

	}


	public HomePage enterTaskDate(String tskDate){
		driver.findElement(By.xpath("//div[text()="+tskDate+"]")).click();

		return this;
	}

	public  String verifyUnderLine()
	{

		WebElement task= driver.findElement(By.xpath("//div/mat-card[3]/mat-card-content/span[1]"));
		String beforeclickchkbox= task.getCssValue("text-decoration");
		System.out.println("before click checkbox"+beforeclickchkbox);
		Actions actions =new Actions(driver);
		actions.click(task);
		actions.perform();
		String Afterclickchkbox= task.getCssValue("text-decoration");
		System.out.println("After click checkbox"+Afterclickchkbox);
		return Afterclickchkbox;

	}	



	public HomePage verifyAllTaskspage(String data) {
		verifyPartialText(locateElement("xpath","//div[text()='All Tasks']"),data);
		return this;
	}



	public HomePage verifyFavoritespage(String data) {
		verifyPartialText(locateElement("xpath","//div[text()='Important Tasks']"),data);
		return this;
	}


	public HomePage enterTaskTitle(String tsktitle){
		clearAndType(locateElement("name","taskTitle"), tsktitle);
		return this;
	}


	public HomePage enterTaskDescription(String tskDesc){
		clearAndType(locateElement("name","taskDesc"), tskDesc);
		return this;
	}


	public HomePage clickAddTask(){
		click(locateElement("xpath","//button[@id='addTask']"));
		return this;

	}



}










